<?php 
    session_start();
    require_once 'config/connect.php';

    $page_title = 'Contact'; 
    $sub_title = 'Get in touch with us'; 
    include 'inc/header.php'; 
?>

<?php include 'inc/nav.php'; ?>

<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row"> 
					
                    <div class="col-md-12"></div>
	
                    <p> Example Contact Page</p>

                </div> <!-- Close row --> 
            </div> <!-- Close container --> 
        </div> <!-- Close content-blog --> 
</section>  
                
<!-- Footer --> 
<?php include 'inc/footer.php' ?>


