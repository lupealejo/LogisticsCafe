			<div class="menu-wrap">
				<div id="mobnav-btn">Menu <i class="fa fa-bars"></i></div>
				<ul class="sf-menu">	
				<li>
						<a href="#">Products</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="index.php">Menu Items</a></li>
						</ul>
					</li>
					<li>
						<a href="#">Menus</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="categories.php">View Menus</a></li>
							<li><a href="addcategory.php">Add Menus</a></li>
						</ul>
					</li>
					<li>
						<a href="#">Orders</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="orders.php">View Orders</a></li>
						</ul>
					</li>
					<li>
						<a href="#">Customers</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="customers.php">View Customers</a></li>
						</ul>
					</li>
					<li>
						<a href="#">Reviews</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="reviews.php">View Reviews</a></li>
						</ul>
					</li>
					<li>
						<a href="#">My Account</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="../logout.php"> Logout </a></li>
						</ul>
					</li>
				</ul>
		</div>
	</header>
