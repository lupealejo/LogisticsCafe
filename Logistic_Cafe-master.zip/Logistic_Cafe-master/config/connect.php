<?php

    // Database: AWS RDS Credentials
    $host                   = 'cst438.xxxxxxxxxxx.us-west-2.rds.amazonaws.com:3306';
    $port                   = '3306';
    $dbname                 = 'cst438'; 
    $username               = 'xxxxxxx'; 
    $password               = 'xxxxxxx';

    $conn = mysqli_connect($host, $username, $password); 
?>
