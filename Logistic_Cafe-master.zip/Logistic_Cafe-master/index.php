<?php 
    session_start();

    require_once 'config/connect.php';
    include 'inc/index_header.php'; 
?>

<?php include 'inc/nav.php'; ?>

	<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
                    <div class="col-md-12"></div>
                    
                    <!-- Add Slider : @NORMA & @LUPE --> 
	
                    <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin venenatis imperdiet tincidunt. Praesent velit eros, scelerisque sit amet orci et, tempor sagittis magna. In congue neque vel felis sagittis bibendum. Nullam mattis vestibulum odio, vitae viverra tellus molestie vel. Praesent eget consectetur velit. Morbi viverra feugiat cursus. Ut in porta massa, at mattis arcu. Donec id ex id est dictum egestas. Duis dapibus magna ut est maximus placerat. Donec rhoncus feugiat quam, gravida dignissim magna bibendum nec.</p>

                    <p>Integer vestibulum augue in maximus feugiat. Morbi volutpat vitae turpis at faucibus. Nam lobortis ut leo vel feugiat. Donec scelerisque luctus ipsum, et accumsan enim accumsan non. Mauris tempus ex aliquam aliquam ornare. Cras magna eros, scelerisque at gravida at, iaculis non mi. Sed volutpat odio ut tortor tincidunt iaculis. Vivamus et erat eget nunc consequat blandit. Nulla ut tincidunt tellus. Quisque malesuada risus vitae metus venenatis, eget mollis nunc efficitur. Maecenas pulvinar, erat sed blandit porta, odio urna gravida nulla, accumsan congue nisl magna eget lorem. Nullam eget purus ut dui ornare ornare eu ac erat. Mauris posuere mauris nisl, quis finibus lectus laoreet a. Donec metus turpis, lacinia id imperdiet ut, condimentum ut velit. Curabitur convallis velit lacinia eleifend lobortis.</p>

                    <p>Etiam non felis velit. Praesent blandit sapien arcu. Proin maximus pulvinar metus, ut mollis tortor venenatis quis. Praesent dapibus nisi eu arcu tempor mollis. Pellentesque commodo sed purus eget malesuada. Aliquam sed blandit tortor, quis porta dui. Duis pellentesque, nunc sit amet consectetur eleifend, ex augue lacinia orci, eu ultricies massa nulla eu risus. Suspendisse aliquam est sed felis dictum vulputate. Phasellus rhoncus sapien suscipit odio blandit semper. Curabitur odio diam, pulvinar ac sodales nec, facilisis et ligula. Etiam pharetra nisl ornare orci pharetra convallis. Quisque elementum commodo sem, vitae ornare nulla euismod non.</p>

                    <p>Etiam id diam auctor odio lobortis convallis. Aenean volutpat lectus felis, a condimentum nibh ullamcorper in. Duis finibus ullamcorper urna quis blandit. Etiam egestas quam quis feugiat tincidunt. Proin egestas est ut tempor volutpat. Sed eu metus elementum, tempor ligula elementum, egestas libero. Morbi mollis gravida lacus, in volutpat velit auctor at. Aenean fringilla lacus quis efficitur bibendum. Fusce at porta nisi. Ut id eros in neque sodales consectetur id non nunc. Morbi porttitor massa ac mauris varius bibendum. Donec feugiat condimentum turpis vitae elementum. Suspendisse vel gravida tortor. Aenean semper eget dolor sit amet posuere.</p>

                </div> <!-- Close row --> 
            </div> <!-- Close container --> 
        </div> <!-- Close content-blog --> 
</section>  
                
<!-- Footer --> 
<?php include 'inc/footer.php' ?>
